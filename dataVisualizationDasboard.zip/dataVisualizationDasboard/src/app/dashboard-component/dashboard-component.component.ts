import { Component, OnInit } from '@angular/core';
import { ChartDataServiceService } from 'src/app/chart-data-service.service';
@Component({
  selector: 'app-dashboard-component',
  templateUrl: './dashboard-component.component.html',
  styleUrls: ['./dashboard-component.component.css']
})
export class DashboardComponentComponent implements OnInit {
  private data = [
    { "label": "Vue", "value": "136443" },
    { "label": "React", "value": "150793" },
    { "label": "Angular", "value": "62342" },
    { "label": "Backbone", "value": "27647" },
    { "label": "Ember", "value": "21471" },
  ];

  public PassData1 = [
    { "label": "Laptop", "value": "1" },
    { "label": "Computer", "value": "1" },
    { "label": "Phones", "value": "7" },
    { "label": "Tablet", "value": "0" },
    { "label": "Car", "value": "1" },
    { "label": "Tv", "value": "3" },
    { "label": "Pendrive", "value": "4" },
    { "label": "DVD", "value": "2" },
    { "label": "Drive", "value": "6" },
    { "label": "Tv", "value": "3" },
  ];

  public PassData2 = [
    { "label": "Male", "value": "1364" },
    { "label": "Female", "value": "1507" },
    { "label": "Transgender", "value": "62" },
    { "label": "Prefer not to say", "value": "27" },
  ];
  constructor(private chartService: ChartDataServiceService) { }

  ngOnInit(): void {
    this.chartService.setBarChartData(this.data);
  }

}
