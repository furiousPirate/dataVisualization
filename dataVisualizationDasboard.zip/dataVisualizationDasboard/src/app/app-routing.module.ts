import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BarChartComponentComponent } from './bar-chart-component/bar-chart-component.component';
import { DashboardComponentComponent } from './dashboard-component/dashboard-component.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', component: DashboardComponentComponent },
  { path: 'dashboard', component: DashboardComponentComponent },
  { path: 'barChart', component: BarChartComponentComponent},
  { path: 'barChart/:isLoadedUsingService', component: BarChartComponentComponent},
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
