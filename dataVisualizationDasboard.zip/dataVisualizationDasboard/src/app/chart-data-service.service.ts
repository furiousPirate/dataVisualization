import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ChartDataServiceService {
  private barChartData = new BehaviorSubject<any>({});
  private url: string = '/assets/barData.json';
  constructor(private http: HttpClient) { }

  setBarChartData(barChartArray: any) {
    this.barChartData.next(barChartArray);
  }

  retriveBarChartData(): Observable<any> {
    return this.barChartData.asObservable();
  }

  getBarChartData() {
    return this.http.get<any>(this.url)
  }

}
