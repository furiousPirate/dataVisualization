import { Component, OnInit,Input,OnDestroy } from '@angular/core';
import * as d3 from 'd3';
import { ChartDataServiceService } from 'src/app/chart-data-service.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-bar-chart-component',
  templateUrl: './bar-chart-component.component.html',
  styleUrls: ['./bar-chart-component.component.css']
})
export class BarChartComponentComponent implements OnInit, OnDestroy {
  public data : any;
  private svg: any;
  private margin = 50;
  private width = 600 - (this.margin * 2);
  private height = 800 - (this.margin * 2);
  private maxNumber: number = 0;
  @Input() barData: any;
  @Input() header: any;

  private createSvg(): void {
    this.svg = d3.select("figure#bar")
      .append("svg")
      .attr("width", this.width + (this.margin * 2))
      .attr("height", this.height + (this.margin * 2))
      .attr("transform","rotate(" + 90 + ")")
      .append("g")
      .attr("transform", "translate(" + this.margin + "," + this.margin + ")");

  }

  private drawBars(data: any[]): void {
    const x = d3.scaleBand()
      .range([0, this.width])
      .domain(data.map(d => d.label))
      .padding(0.2);

    this.svg.append("g")
      .attr("transform", "translate(0," + this.height + ")")
      .call(d3.axisBottom(x))
      .selectAll("text")
      .attr("transform", "translate(0,0)rotate(0)")
      .style("text-anchor", "center");
    const y = d3.scaleLinear()
      .domain([0, this.maxNumber])
      .range([this.height, 0]);
    this.svg.append("g")
      .call(d3.axisLeft(y));
    this.svg.selectAll("bars")
      .data(data)
      .enter()
      .append("rect")
      .attr("x", (d: any) => x(d.label))
      .attr("y", (d: any) => y(d.value))
      .attr("width", x.bandwidth())
      .attr("height", (d: any) => this.height - y(d.value))
      .attr("fill", (d: any) => this.setBarColor(d))
      .append('title')
      .text((data:any) => `Label : ${data.label} \nValue : ${data.value}`);

  }

  constructor(private chartService: ChartDataServiceService, private routerParams: ActivatedRoute) { }

  ngOnInit(): void {
    if (Boolean(this.routerParams.snapshot.params['isLoadedUsingService']) == true) {
      this.chartService.retriveBarChartData().subscribe((data: any) => {
        if (data.length > 0) {
          this.data = data;
          this.header = 'Number of Users of different Javascript Framework Users';
          this.setMaxNumber();
        }
        else {
          this.chartService.getBarChartData().subscribe((data: any) => {
            this.data = data;
            this.header = 'Some random Bar Graph';
            this.setMaxNumber();
          })
        }
        
      })
    }
    else if (this.barData) {
      this.data = this.barData;      
      this.setMaxNumber();
    }
    else {
      this.chartService.getBarChartData().subscribe((data: any) => {
        this.data = data;
        this.header = 'Some random Bar Graph';
        this.setMaxNumber();
      })
    }
    
  }

  setBarColor(data: any) {
    if (Number(data.value) > this.maxNumber * 0.75) {
      return 'green';
    }
    else if (Number(data.value) < this.maxNumber * 0.25) {
      return 'red';
    }
    return 'orange';
  }


  setMaxNumber() {
    this.maxNumber = Number(this.data.reduce((a: any, b: any) => Number(a.value) > Number(b.value) ? a : b).value)
    this.createSvg();
    this.drawBars(this.data);
  }

  sortAsc() {
    d3.select("svg").remove();
    this.data.sort((a: any, b: any) => parseFloat(a.value) - parseFloat(b.value));
    this.setMaxNumber();
  }

  sortDesc() {
    d3.select("svg").remove();
    this.data.sort((a: any, b: any) => parseFloat(b.value) - parseFloat(a.value));
    this.setMaxNumber();
  }

  ngOnDestroy() {
    d3.select("svg").remove();
  }
}

